// //#1
// // #include <iostream>
// // using namespace std;
// //
// // int main() {
// //     int tugilgan_yil;
// //     cout << "Tug'ilgan yilingizni kiriting: ";
// //     cin >> tugilgan_yil;
// //
// //     int joriy_yil = 2025;
// //     int yosh = joriy_yil - tugilgan_yil;
// //
// //     cout << "Sizning yoshingiz: " << yosh << endl;
// //
// //     return 0;
// // }
//
// //#2
//
// #include <iostream>
// using namespace std;
//
// int main() {
//     double uzunlik, en;
//     cout << "To'rtburchakning uzunligi va enini kiriting: ";
//     cin >> uzunlik >> en;
//
//     double yuza = uzunlik * en;
//     double perimetr = 2 * (uzunlik + en);
//
//     cout << "Yuza: " << yuza << endl;
//     cout << "Perimetr: " << perimetr << endl;
//
//     return 0;
// }
//
// //#3

#include <iostream>
using namespace std;

// int main() {
//     double C;
//     cin >> C;
//     double F = C * 9 / 5 + 32;
//     cout << F << " F";
//     return 0;
// }
//


//#4

#include <iostream>
using namespace std;

// int main() {
//     int a, b, c;
//     cin >> a >> b >> c;
//     int sum = a + b + c;
//     int mult = a * b * c;
//     double avg = sum / 3.0;
//     cout << "Yig'indi: " << sum << endl;
//     cout << "Ko'paytma: " << mult << endl;
//     cout << "O'rtacha: " << avg;
//     return 0;
// }


//#5

// int main() {
//     int a, b;
//     cin >> a >> b;
//     cout << "Bo'linma: " << a / b << endl;
//     cout << "Qoldiq: " << a % b;
//     return 0;
// }


//6
//
// int main() {
//     double som;
//     cin >> som;
//     double dollar = som / 11960;
//     cout << "Dollar: " << dollar << endl;
//     cout << "Qaytib so'm: " << dollar * 11960;
//     return 0;
// }


//7
//
// int main() {
//     int seconds;
//     cin >> seconds;
//     int hours = seconds / 3600;
//     int minutes = (seconds % 3600) / 60;
//     int secs = seconds % 60;
//     cout << hours << ":" << minutes << ":" << secs;
//     return 0;
// }
//


//8
// int main() {
//     int n;
//     cin >> n;
//     int sum = n / 10 + n % 10;
//     cout << sum;
//     return 0;
// }

//9
// int main() {
//     double r;
//     cin >> r;
//     const double pi = 3.14159;
//     cout << "Diametr: " << 2 * r << endl;
//     cout << "L: " << 2 * pi * r << endl;
//     cout << "S: " << pi * r * r;
//     return 0;
// }


//10
// int main() {
//     double price, discount;
//     cin >> price >> discount;
//     double newPrice = price * (100 - discount) / 100;
//     cout << "Yangi narx: " << newPrice << " so'm";
//     return 0;
// }


//11

#include <iostream>
// using namespace std;
//
// int main() {
//     int n;
//     cin >> n;
//     int a = n / 100;
//     int b = (n / 10) % 10;
//     int c = n % 10;
//     cout << c << b << a;
//     return 0;
// }
//

//12
//
// #include <iostream>
// using namespace std;
//
// int main() {
//     double kmh;
//     cin >> kmh;
//     double ms = kmh * 1000 / 3600;
//     cout << ms << " m/s";
//     return 0;
// }

//13
// #include <iostream>
// using namespace std;
//
// int main() {
//     double a, b, c;
//     cin >> a >> b >> c;
//     double D = b * b - 4 * a * c;
//     cout << "Diskriminant: " << D;
//     return 0;
// }

//14
// #include <iostream>
// using namespace std;
//
// int main() {
//     int n;
//     cin >> n;
//     int a = n / 1000;
//     int b = (n / 100) % 10;
//     int c = (n / 10) % 10;
//     int d = n % 10;
//     int sum = a + b + c + d;
//     int mult = a * b * c * d;
//     cout << "Yig'indi: " << sum << endl;
//     cout << "Ko'paytma: " << mult;
//     return 0;
// }

//15
#include <iostream>
// using namespace std;
//
// int main() {
//     double m;
//     cin >> m;
//     const double c = 300000000;
//     double E = m * c * c;
//     cout << E << " J";
//     return 0;
// }