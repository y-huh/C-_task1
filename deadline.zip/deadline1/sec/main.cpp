//1
// #include <iostream>
// using namespace std;
//
// int main() {
//     int son;
//     cout << "Son kiriting: ";
//     cin >> son;
//
//     if (son > 0) {
//         cout << "Musbat son" << endl;
//     } else if (son < 0) {
//         cout << "Manfiy son" << endl;
//     } else {
//         cout << "Nol" << endl;
//     }
//     return 0;
// }

//2
// #include <iostream>
// using namespace std;
//
// int main() {
//     int son;
//     cout << "Son kiriting: ";
//     cin >> son;
//
//     if (son % 2 == 0) {
//         cout << "Juft son" << endl;
//     } else {
//         cout << "Toq son" << endl;
//     }
//     return 0;
// }


//3
// #include <iostream>
// using namespace std;
//
// int main() {
//     int a, b;
//     cout << "Ikkita son kiriting: ";
//     cin >> a >> b;
//     if (b < a) {
//         cout << a << "son kattaroq" << b << endl;
//     }
//     else if (b > a) {
//         cout << b << "son kattaroq" << a << endl;
//     }
//     else if (a == b) {
//         cout << a << "sonlar teng" << endl;
//     }
//
//     return 0;
// }

//4
// #include <iostream>
// using namespace std;
//
// int main() {
//     int yosh;
//     cout << "Yosh kiriting: ";
//     cin >> yosh;
//
//     if (yosh >= 0 && yosh <= 12) {
//         cout << "Bola" << endl;
//     } else if (yosh >= 13 && yosh <= 19) {
//         cout << "O'smir" << endl;
//     } else if (yosh >= 20 && yosh <= 59) {
//         cout << "Kattalar" << endl;
//     } else if (yosh >= 60) {
//         cout << "Keksa" << endl;
//     } else {
//         cout << "Noto'g'ri yosh" << endl;
//     }
//     return 0;
// }


//5
// #include <iostream>
// using namespace std;
//
// int main() {
//     int kun;
//     cout << "Hafta kuni raqamini kiriting (1-7): ";
//     cin >> kun;
//
//     switch(kun) {
//         case 1: cout << "Dushanba" << endl; break;
//         case 2: cout << "Seshanba" << endl; break;
//         case 3: cout << "Chorshanba" << endl; break;
//         case 4: cout << "Payshanba" << endl; break;
//         case 5: cout << "Juma" << endl; break;
//         case 6: cout << "Shanba" << endl; break;
//         case 7: cout << "Yakshanba" << endl; break;
//         default: cout << "Noto'g'ri raqam" << endl;
//     }
//     return 0;
// }



//6
// #include <iostream>
// using namespace std;
//
// int main() {
//     int x, y, z;
//     cout << "Uchburchak tomonlarini kiriting: ";
//     cin >> x >> y >> z;
//
//     if (x == y && y == z) {
//         cout << "Teng tomonli uchburchak" << endl;
//     } else if (x == y || x == z || y == z) {
//         cout << "Teng yonli uchburchak" << endl;
//     } else {
//         cout << "Turli tomonli uchburchak" << endl;
//     }
//     return 0;
// }


//7
// #include <iostream>
// using namespace std;
//
// int main() {
//     double num1, num2;
//     char amal;
//     cout << "Amalni kiriting (son1 + son2): ";
//     cin >> num1 >> amal >> num2;
//
//     switch(amal) {
//         case '+':
//             cout << "Natija: " << num1 + num2 << endl;
//             break;
//         case '-':
//             cout << "Natija: " << num1 - num2 << endl;
//             break;
//         case '*':
//             cout << "Natija: " << num1 * num2 << endl;
//             break;
//         case '/':
//             if (num2 != 0) {
//                 cout << "Natija: " << num1 / num2 << endl;
//             } else {
//                 cout << "Xato: 0 ga bo'lib bo'lmaydi" << endl;
//             }
//             break;
//         default:
//             cout << "Noto'g'ri amal" << endl;
//     }
//     return 0;
// }



//8
// #include <iostream>
// using namespace std;
//
// int main() {
//     int yil;
//     cout << "Yil kiriting: ";
//     cin >> yil;
//
//     if (yil % 4 == 0 ) {
//         cout << "Kabisa yil" << endl;
//     } else {
//         cout << "Oddiy yil" << endl;
//     }
//     return 0;
// }


//9
// #include <iostream>
// using namespace std;
//
// int main() {
//     int ball;
//     cout << "Ball kiriting (0-100): ";
//     cin >> ball;
//
//     if (ball >= 90 && ball <= 100) {
//         cout << "Baho: A (Excellent)" << endl;
//     } else if (ball >= 80 && ball <= 89) {
//         cout << "Baho: B (Good)" << endl;
//     } else if (ball >= 70 && ball <= 79) {
//         cout << "Baho: C (Satisfactory)" << endl;
//     } else if (ball >= 60 && ball <= 69) {
//         cout << "Baho: D (Pass)" << endl;
//     } else if (ball >= 0 && ball <= 59) {
//         cout << "Baho: F (Fail)" << endl;
//     }
//     return 0;
// }


//10
// #include <iostream>
// using namespace std;
//
// int main() {
//     int oy, yil;
//     cout << "Oy va yil kiriting: ";
//     cin >> oy >> yil;
//
//     int kunlar;
//     switch(oy) {
//         case 1: case 3: case 5: case 7: case 8: case 10: case 12:
//             kunlar = 31;
//             break;
//         case 4: case 6: case 9: case 11:
//             kunlar = 30;
//             break;
//         case 2:
//             if ((yil % 4 == 0 && yil % 100 != 0) || (yil % 400 == 0)) {
//                 kunlar = 29;
//             } else {
//                 kunlar = 28;
//             }
//             break;
//         default:
//             cout << "Noto'g'ri oy" << endl;
//             return 1;
//     }
//     cout << kunlar << " kun" << endl;
//     return 0;
// }


//11
// #include <iostream>
// #include <cmath>
// using namespace std;
//
// int main() {
//     double a, b, c;
//     cout << "a, b, c koeffitsiyentlarini kiriting: ";
//     cin >> a >> b >> c;
//
//     double D = b * b - 4 * a * c;
//
//     if (D > 0) {
//         cout << "2 ta haqiqiy ildiz bor" << endl;
//     } else if (D == 0) {
//         cout << "1 ta haqiqiy ildiz bor" << endl;
//     } else {
//         cout << "Haqiqiy ildiz yo'q" << endl;
//     }
//     return 0;
// }