//1

//
// #include <iostream>
// using namespace std;
//
// int main() {
//     int N;
//     cout << "N kiriting: ";
//     cin >> N;
//
//     for (int i = 1; i <= N; i++) {
//         cout << i << " ";
//     }
//     cout << endl;
//
//     return 0;
// }

//2

// #include <iostream>
// using namespace std;
//
// int main() {
//     int N;
//     cout << "Sonlar sonini kiriting: ";
//     cin >> N;
//
//     int sum = 0, i = 0, num;
//
//     cout << N << " ta son kiriting: ";
//     while (i < N) {
//         cin >> num;
//         sum += num;
//         i++;
//     }
//
//     cout << "Yig'indi: " << sum << endl;
//
//     return 0;
// }

//3
//
// #include <iostream>
// using namespace std;
//
// int main() {
//     int N;
//     cout << "N kiriting: ";
//     cin >> N;
//
//     long long factorial = 1;
//     for (int i = 1; i <= N; i++) {
//         factorial *= i;
//     }
//
//     cout << factorial << endl;
//
//     return 0;
// }

//4

// #include <iostream>
// using namespace std;
//
// int main() {
//     int son;
//     cout << "Son kiriting: ";
//     cin >> son;
//
//     for (int i = 1; i <= 10; i++) {
//         cout << son << " x " << i << " = " << son * i << endl;
//     }
//
//     return 0;
// }

// //5

// #include <iostream>
// #include <string>
// using namespace std;
//
// int main() {
//     string parol;
//     string togri_parol = "1234";
//
//     do {
//         cout << "Parolni kiriting: ";
//         cin >> parol;
//
//         if (parol != togri_parol) {
//             cout << "Noto'g'ri parol" << endl;
//         }
//     } while (parol != togri_parol);
//
//     cout << "Xush kelibsiz!" << endl;
//
//     return 0;
// }

// //6
//
// #include <iostream>
// using namespace std;
//
// int main() {
//     int N;
//     cout << "N kiriting: ";
//     cin >> N;
//
//     for (int i = 2; i <= N; i++) {
//         bool tub = true;
//         for (int j = 2; j * j <= i; j++) {
//             if (i % j == 0) {
//                 tub = false;
//                 break;
//             }
//         }
//         if (tub) {
//             cout << i << " ";
//         }
//     }
//     cout << endl;
//
//     return 0;
// }

// //7
// #include <iostream>
// using namespace std;
//
// int main() {
//     int son;
//     cout << "Son kiriting: ";
//     cin >> son;
//
//     int sum = 0;
//     while (son > 0) {
//         sum += son % 10;
//         son /= 10;
//     }
//
//     cout << sum << endl;
//
//     return 0;
// }
//
//8
// #include <iostream>
// using namespace std;
//
// int main() {
//     int N;
//     cout << "N kiriting: ";
//     cin >> N;
//
//     if (N >= 1) cout << "0 ";
//     if (N >= 2) cout << "1 ";
//
//     int a = 0, b = 1;
//     for (int i = 3; i <= N; i++) {
//         int c = a + b;
//         cout << c << " ";
//         a = b;
//         b = c;
//     }
//     cout << endl;
//
//     return 0;
// }

// //10
//
// #include <iostream>
// #include <climits>
// using namespace std;
//
// int main() {
//     int N;
//     cout << "Sonlar sonini kiriting: ";
//     cin >> N;
//
//     int eng_katta = INT_MIN;
//     int eng_kichik = INT_MAX;
//
//     cout << N << " ta son kiriting: ";
//     for (int i = 0; i < N; i++) {
//         int num;
//         cin >> num;
//
//         if (num > eng_katta) eng_katta = num;
//         if (num < eng_kichik) eng_kichik = num;
//     }
//
//     cout << "Eng katta: " << eng_katta << endl;
//     cout << "Eng kichik: " << eng_kichik << endl;
//
//     return 0;
// }

//11
//
// #include <iostream>
// using namespace std;
//
// int main() {
//     int son;
//     cout << "Son kiriting: ";
//     cin >> son;
//
//     int teskari = 0;
//     while (son > 0) {
//         teskari = teskari * 10 + son % 10;
//         son /= 10;
//     }
//
//     cout << teskari << endl;
//
//     return 0;
// }

//12

// #include <iostream>
// using namespace std;
//
// int main() {
//     int a, b;
//     cout << "Ikkita son kiriting: ";
//     cin >> a >> b;
//
//     // EKUB topish
//     int x = a, y = b;
//     while (y != 0) {
//         int temp = y;
//         y = x % y;
//         x = temp;
//     }
//     int ekub = x;
//
//     // EKUK topish
//     int ekuk = (a * b) / ekub;
//
//     cout << "EKUB: " << ekub << endl;
//     cout << "EKUK: " << ekuk << endl;
//
//     return 0;
// }

//13
//
// #include <iostream>
// using namespace std;
//
// int main() {
//     int N;
//     cout << "N kiriting: ";
//     cin >> N;
//
//     for (int i = 1; i <= N; i++) {
//         int sum = 0;
//         for (int j = 1; j < i; j++) {
//             if (i % j == 0) {
//                 sum += j;
//             }
//         }
//         if (sum == i) {
//             cout << i << " ";
//         }
//     }
//     cout << endl;
//
//     return 0;
// }
//14
#include <iostream>
// using namespace std;
//
// int main() {
//     int N;
//     cout << "Qatorlar sonini kiriting: ";
//     cin >> N;
//
//     for (int i = 1; i <= N; i++) {
//         // Bo'shliqlar
//         for (int j = 1; j <= N - i; j++) {
//             cout << " ";
//         }
//         // Yulduzlar
//         for (int j = 1; j <= 2 * i - 1; j++) {
//             cout << "*";
//         }
//         cout << endl;
//     }
//
//     return 0;
// }
//
//15

#include <iostream>
using namespace std;

int main() {
    int son;

    while (true) {
        cout << "Son kiriting (0 chiqish): ";
        cin >> son;

        if (son == 0) break;

        // Xonalar soni
        int temp = son, xonalar = 0, sum = 0;
        while (temp > 0) {
            sum += temp % 10;
            temp /= 10;
            xonalar++;
        }

        // Palindrom tekshirish
        temp = son;
        int teskari = 0;
        while (temp > 0) {
            teskari = teskari * 10 + temp % 10;
            temp /= 10;
        }

        cout << "Son: " << son << endl;
        cout << "  Xonalar: " << xonalar << endl;
        cout << "  Palindrom: " << (son == teskari ? "Ha" : "Yo'q") << endl;
        cout << "  Yig'indi: " << sum << endl;
        cout << endl;
    }

    return 0;
}